<?php

$container['view'] = function ($container){
    $view = new \Slim\Views\Twig(
        $container['settings']['view']['templatePath'],
        $container['settings']['view']['twig']
    );

    $basePath = rtrim(str_ireplace('index.php', '', $container['request']->getUri()->getBasePath()), '/');
    $view->addExtension(new Slim\Views\TwigExtension($container['router'], $basePath));
    $view->addExtension(new Twig\Extension\DebugExtension());

    return $view;
};

$container[\Psr\Log\LoggerInterface::class] = function ($container) {
    $logger = new Monolog\Logger('logger');
    $logFile = '../../logs/GigSpace.log';

    // Create Log Formatting
    $fileHandler = new Monolog\Handler\StreamHandler($logFile, \Monolog\Logger::DEBUG);
    $dateFormat = 'd/M/Y H:i:s';
    $output = "%datetime% | %level_name% | %message% | %context% | %extra%\n";
    $formatter = new Monolog\Formatter\LineFormatter($output, $dateFormat, false, true);
    $fileHandler->setFormatter($formatter);

    $logger->pushHandler($fileHandler);

    return $logger;
};

$container[\GigSpace\SessionWrapperInterface::class] = function ($container) {
    return new \GigSpace\FileSessionWrapper($container['LibSodiumWrapper']);
};

$container[\GigSpace\SessionManagerInterface::class] = function ($container) {
    return new \GigSpace\SessionManager();
};

$container['Base64Wrapper'] = function ($container) {
    return new GigSpace\Base64Wrapper();
};

$container['BcryptWrapper'] = function ($container) {
    return new GigSpace\BcryptWrapper($container['settings']['bcrypt']);
};

$container['LibSodiumWrapper'] = function ($container) {
    return new GigSpace\LibSodiumWrapper($container['settings']['naKey'], $container['Base64Wrapper']);
};

$container['Validator'] = function ($container) {
    return new GigSpace\Validator();
};

$container['QueryBuilder'] = function ($container) {
    $connection = \Doctrine\DBAL\DriverManager::getConnection($container['settings']['doctrine']);
    return $connection->createQueryBuilder();
};

$container['SqlQueries'] = function ($container) {
    return new GigSpace\SqlQueries($container[\Psr\Log\LoggerInterface::class], $container['QueryBuilder']);
};
