<?php

use \Psr\Http\Message\{ServerRequestInterface, ResponseInterface};

$loggedInMiddleware = function (ServerRequestInterface $request, ResponseInterface $response, callable $next) use ($app) {

    // Gets the route name that matches the requested URL.
    $route = $request->getAttribute('route');
    $routeName = $route->getName();

    // Define routes people who aren't logged in can access and what logged in users can't.
    $notLoggedInRoutes = [
        'welcomepage',
        'welcomepagepost',
        'login',
        'loginsubmit',
        'register',
        'registrationfailed',
    ];

    $notGuestRoutes = [
        'friendslist',
        'chats',
        'chatspost',
        'chatswith',
        'chatswithpost',
        'friendsfeed',
        'friendsfeedpost',
        'myprofile',
        'myprofilepost',
        'createband',
        'createbandpost',
        'mybandprofile',
        'mybandprofilepost'
    ];

    $wrapper = $app->getContainer()->get(\GigSpace\SessionWrapperInterface::class);
    $manager = $app->getContainer()->get(\GigSpace\SessionManagerInterface::class);

    // Start the session.
    $manager::start($wrapper);

    if (!$wrapper->check('userId') && !in_array($routeName, $notLoggedInRoutes) && !$wrapper->check('guestId') && !in_array($routeName, $notLoggedInRoutes)) {
        // If not logged and not private, redirect to welcomepage.
        return $response->withRedirect('/public_php/gigspace_public/');
    } elseif ($wrapper->check('userId') && in_array($routeName, $notLoggedInRoutes)) {
        // Else if logged in and going to not logged in page go to newsfeed.
        return $response->withRedirect('/public_php/gigspace_public/newsfeed');
    } elseif (!$wrapper->check('userId') && in_array($routeName, $notGuestRoutes)){
        //Else if a guest user attempts to access routes which are available to full user
        return $response->withRedirect('/public_php/gigspace_public/guesterror');
    } else {
        // Else carry on with request.
        $response = $next($request, $response);
    }

    return $response;
};

//Add Middleware to App.
$app->add($loggedInMiddleware);