<?php

/**
 * This route is for a bands profile, it populates the template useing the bandname,
 *  it gathers all the details of the band from the db by its bandname.
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->get('/bandprofile/{bandname}', function (Request $request, Response $response, $args) use ($app) {

    $queries = $this->get('SqlQueries');

    $bandname = $args['bandname'];

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');
    $existingBand = $queries->userInBand($userId);

    $band = $queries->getBandDetails($bandname);
    $bandResult = $band->execute()->fetchAllAssociative();

    $bandId = $queries->getBandDetails($bandname);
    $bandIdResult = $bandId->execute()->fetchAssociative()['band_id'];

    $bandPosts = $queries->getBandPosts($bandname);
    $bandPostResults = $bandPosts->execute()->fetchAllAssociative();

    $members = $queries->getMembers($bandIdResult);
    $memberResult = $members->execute()->fetchAllAssociative();

    return $this->view->render($response,
        'bandprofile.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => 'bandprofilepost',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => "Band Profile",
            'id' => $userId,
            'inband' => $existingBand,
            'bandDetails' => $bandResult,
            'members' => $memberResult,
            'bandPosts' => $bandPostResults
        ]);

})->setName('bandprofile');

