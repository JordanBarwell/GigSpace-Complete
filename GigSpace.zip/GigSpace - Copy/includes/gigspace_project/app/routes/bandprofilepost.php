<?php

/**
 * if a user is admin they can perform certain actions like update the bio
 * or disband the band, if the user is not admin but a memeber the action the post
 * will perform is removing them from the band if the select leave
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->post('/bandprofilepost/{bandname}', function (Request $request, Response $response) use ($app) {

    $queries = $this->get('SqlQueries');

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');
    $existingBand = $queries->userInBand($userId);

    return $this->view->render($response,
        'bandprofile.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => 'bandprofilepost',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => '',
            'id' => $userId,
            'inband' => $existingBand,
        ]);

})->setName('bandprofilepost');
