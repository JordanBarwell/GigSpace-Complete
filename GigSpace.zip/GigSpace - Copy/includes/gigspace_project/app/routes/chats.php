<?php

/**
 * this route is for the users chats, unfortunatly this does not yet function,
 * however if it were to it would have displayed all the users active chats here
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->get('/chats', function (Request $request, Response $response) use ($app) {

    $queries = $this->get('SqlQueries');

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');

    /*
    $chats = $queries->getChat($userId);
    $chatsResults = $chats->execute()->fetchAllAssociative();
    */

    return $this->view->render($response,
        'chats.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => 'chatspost',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'Chats',
            'currentUser' => $userId,
            'id' => $userId,
           // 'chatResults' => $chatsResults,
        ]);

})->setName('chats');

