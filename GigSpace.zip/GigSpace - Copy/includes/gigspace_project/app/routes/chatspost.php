<?php

/**
 * this would have been the route for searching a friend to chat with
 * if a chat had not been started yet between that friend
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->post('/chatspost', function (Request $request, Response $response) use ($app) {

    $queries = $this->get('SqlQueries');
    $validator = $this->get('Validator');

    $userInput = $request->getParsedBody();

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');



    $searchResults = [];
    if (!empty($userInput['search'])) {
        $searchContent = $userInput['search'];
        $cleanedSearch = $validator->validateString('search', $searchContent, 1, 26);
        $search = $queries->searchFriend($cleanedSearch, $userId);
        $searchResults = $search->execute()->fetchAllAssociative();
    }
    /*
       if (isset($_POST['chat'])) {
           if (!$queries->chatExist($userId, $_POST['friendID'])) {
               $startchat = $queries->startChat($userId, $_POST['friendID']);
               $response = $response->withStatus(303);
               return $response->withHeader('Location', 'chats');
           } else {
               $response = $response->withStatus(303);
               return $response->withHeader('Location', 'chats');
           }
       }
       */

    return $this->view->render($response,
        'chats.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => 'chatspost',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'Chats',
            'searchResults' => $searchResults,
            'currentUser' => $userId,
            'id' => $userId,
        ]);

})->
setName('chatspost');
