<?php

/**
 * this route would have displayed chats between the user and a certain friend that
 * they had a chat engaged with
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->get('/chatwith/{username}', function (Request $request, Response $response, $args) use ($app) {

    $queries = $this->get('SqlQueries');

    $username = $args['username'];

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');

    return $this->view->render($response,
        'chatwith.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => "/public_php/gigspace_public/chatwithpost/$username",
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => "Chat With $username",
            'id' => $userId
        ]);

})->setName('chatwith');

