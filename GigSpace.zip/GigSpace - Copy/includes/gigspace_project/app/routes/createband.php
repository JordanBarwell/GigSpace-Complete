<?php

/**
 * this route allows a user to create a band
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->get('/createband', function (Request $request, Response $response) use ($app) {

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');

    return $this->view->render($response,
        'createband.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => 'createbandpost',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'Start A Band',
            'id' => $userId,
        ]);

})->setName('createband');
