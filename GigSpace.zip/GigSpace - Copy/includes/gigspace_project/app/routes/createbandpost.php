<?php

/**
 * when a user has populated the inputs with data, a new band is then formed and stored
 * in a database, a profile is then able to be populated with this data
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->post('/createbandpost', function (Request $request, Response $response) use ($app) {

    $queries = $this->get('SqlQueries');
    $validator = $this->get('Validator');
    $error = '';

    $userInput = $request->getParsedBody();

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');

    $existingBand = $queries->userInBand($userId);

    if (isset($_POST['createBand'])) {
        if (!$existingBand) {
            if (!empty($userInput['bandName'])) {
                if (!empty($userInput['bandBio'])) {
                    $bioContent = $userInput['bandBio'];
                    $cleanedBio = $validator->validateString('bandBio', $bioContent, 1, 256);
                    $bandId = $queries->createBand($userInput['bandName'], $userId);
                    $storeBio = $queries->storeBandBio($cleanedBio, $userId);
                    $queries->updateUserBandId($userId, $bandId);
                    $response = $response->withStatus(303);
                    return $response->withHeader('Location', 'mybandprofile');
                } else {
                    $bandId = $queries->createBand($userInput['bandName'], $userId);
                    $queries->updateUserBandId($userId, $bandId);
                    $response = $response->withStatus(303);
                    return $response->withHeader('Location', 'mybandprofile');
                }
            } else {
                $error = 'you need a name!';
            }
        } else {
            $error = 'Already in a band!';
        }
    }

    return $this->view->render($response,
        'createband.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => 'createbandpost',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'Start A Band',
            'id' => $userId,
            'inband' => $existingBand,
            'error' => $error
        ]);

})->setName('createbandpost');