<?php

/**
 * the friendsfeed returns all posts which were all posted by the users friends
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->get('/friendsfeed', function (Request $request, Response $response) use ($app) {

    $queries = $this->get('SqlQueries');

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');
    $existingBand = $queries->userInBand($userId);

    $posts = $queries->getFriendsPosts($userId);

    $postResults = $posts->execute()->fetchAllAssociative();

    return $this->view->render($response,
        'friendsfeed.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => 'friendsfeedpost',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'Friends Feed',
            'usersStatus' => $postResults,
            'currentUser' => $userId,
            'id' => $userId,
            'inband' => $existingBand,
        ]);

})->setName('friendsfeed');
