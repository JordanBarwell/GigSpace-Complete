<?php

/**
 * this is the post action for the friendsfeed, this allows the user to like friends posts
 *
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->post('/friendsfeedpost', function (Request $request, Response $response) use ($app) {

    $queries = $this->get('SqlQueries');
    $validator = $this->get('Validator');

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');
    $existingBand = $queries->userInBand($userId);

    $userInput = $request->getParsedBody();

    $posts = $queries->getFriendsPosts($userId);
    $postResults = $posts->execute()->fetchAllAssociative();

        if (isset($_POST['likeStatus']) && isset($_POST['postID'])) {
            if (!$queries->likeExist($_POST['postID'], $userId)) {
                $likePost = $queries->likePost($_POST['postID'], $userId);
                $count = $queries->updateLikes($_POST['postID']);
                $response = $response->withStatus(303);
                return $response->withHeader('Location', 'friendsfeed');
            } else {
                $error = "You've Already Liked That Post";
            }
        }

    return $this->view->render($response,
        'friendsfeed.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => 'friendsfeedpost',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'friends Feed',
            'postError' => $error,
            'usersStatus' => $postResults,
            'currentUser' => $userId,
            'id' => $userId,
            'inband' => $existingBand,
        ]);

})->setName('friendsfeedpost');
