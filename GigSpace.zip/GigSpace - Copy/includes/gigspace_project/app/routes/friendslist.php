<?php

/**
 * when the user has added some friends, this template will fill with all of
 * those friends whihc the user has added. from here you can visit the profiles of these
 * friends
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->get('/friendslist', function (Request $request, Response $response) use ($app) {

    $queries = $this->get('SqlQueries');

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');
    $existingBand = $queries->userInBand($userId);

    $friendsList = $queries->getFriends($userId);
    $friendResults = $friendsList->execute()->fetchAllAssociative();

    return $this->view->render($response,
        'friendslist.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => '',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'Friends List',
            'userFriends' => $friendResults,
            'currentUser' => $userId,
            'id' => $userId,
            'inband' => $existingBand,
        ]);

})->setName('friendslist');
