
<?php

/**
 * in the event that a guest user tries to access routes that they
 * do not have access to, like the friendslist or friendsfeed for example
 * they will be taken to this alternate route telling them they need to make
 * an account to access this content
 */

use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->get('/guesterror', function (Request $request, Response $response) use ($app) {

    return $this->view->render($response,
        'guesterror.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'You need an account to access this page',
        ]);

})->setName('guesterror');