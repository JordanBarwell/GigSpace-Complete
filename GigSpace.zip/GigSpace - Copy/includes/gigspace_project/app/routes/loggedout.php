<?php

/**
 * once a user has finished with useing the site they can log out
 * to destroy the session or simply press the close button
 */

use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->get('/loggedout', function (Request $request, Response $response) use ($app) {

    $wrapper = $this->get(\GigSpace\SessionWrapperInterface::class);
    $this->get(\GigSpace\SessionManagerInterface::class)::destroy($wrapper);

    return $this->view->render($response,
        'loggedout.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'Logged Out!',
        ]);

})->setName('loggedout');