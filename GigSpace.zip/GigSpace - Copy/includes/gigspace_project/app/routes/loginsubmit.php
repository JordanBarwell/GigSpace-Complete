<?php

/**
 * this route handles the user data which has been inputted,
 * if the users details match that of a user stored in the db then
 * the user will be logged into that account, otherwise errors will
 * be prompted that the incorrect details were entered.
 */

use GigSpace\SessionManagerInterface;
use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->post('/loginsubmit', function (Request $request, Response $response) use ($app) {

    $usernameError = $passwordError = '';

    $queries = $this->get('SqlQueries');
    $validator = $this->get('Validator');

    $userInput = $request->getParsedBody();
    $username = $userInput['SiteUsername'] ?? '';
    $cleanedPassword = $userInput['SitePassword'] ?? '';
    $cleanedUsername = $validator->validateString('SiteUsername', $username);

    if (empty($cleanedPassword)) {
        $passwordError = 'This field is required!';
    } elseif (strlen($cleanedPassword) > 100) {
        $passwordError = 'Password must be less than or equal to 100 characters';
    } elseif (strlen($cleanedPassword) < 5) {
        $passwordError = 'password must be 5 Characters or above';
    }

    if (!$validator->isValid('SiteUsername')) {
        $usernameError = $validator->getError('SiteUsername');
    } elseif (!$validator->doesUsernameMatch('SiteUsername', $username, $queries)) {
        $usernameError = $validator->getError('SiteUsername');
    }

    if (empty($usernameError) && empty($passwordError)) {

        $queries = $this->get('SqlQueries');
        $userData = $queries->getUserData($cleanedUsername);

        if ($userData) {

            $bcryptWrapper = $this->get('BcryptWrapper');
            $passwordVerified = $bcryptWrapper->verify($cleanedPassword, $userData['password']);

            if ($userData['username'] === $cleanedUsername && $passwordVerified) {

                $sessionWrapper = $this->get(SessionWrapperInterface::class);
                $sessionWrapper->set('userId', $userData['user_id']);
                $this->get(SessionManagerInterface::class)::regenerate($sessionWrapper);
                $response = $response->withStatus(303);
                return $response->withHeader('Location', 'newsfeed');

            }
        }

        $usernameError = $passwordError = 'Username or Password is incorrect!';
    }

    return $this->view->render($response,
        'loginform.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => '',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'login',
            'password_error' => $passwordError,
            'username_error' => $usernameError
        ]);

})->setName('loginsubmit');