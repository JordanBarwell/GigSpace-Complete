<?php

/**
 * this route is for the current users own band, if they are a band member or
 * admin this route will be available to view and it populates all data of the
 * current users band
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->get('/mybandprofile', function (Request $request, Response $response) use ($app) {

    $queries = $this->get('SqlQueries');

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');
    $existingBand = $queries->userInBand($userId)['band_id'];
    $band = $queries->userInBand($userId);

    $bandDetails = $queries->getMyBand($existingBand);
    $bandDetailsResult = $bandDetails->execute()->fetchAllAssociative();

    $bandPosts = $queries->getMyBandPosts($existingBand);
    $bandPostResults = $bandPosts->execute()->fetchAllAssociative();

    $members = $queries->getMyMembers($existingBand);
    $membersResult = $members->execute()->fetchAllAssociative();

    return $this->view->render($response,
        'mybandprofile.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => 'mybandprofilepost',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'My Band',
            'members' => $membersResult,
            'id' => $userId,
            'inband' => $existingBand,
            'banddetails' => $bandDetailsResult,
            'bandPosts' => $bandPostResults
        ]);

})->setName('mybandprofile');


