<?php

/**
 * if the user is an admin this page gives them more options other wise if the
 * current user is a member then they can leave the band
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->post('/mybandprofilepost', function (Request $request, Response $response) use ($app) {

    $queries = $this->get('SqlQueries');
    $validator = $this->get('Validator');

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');
    $existingBand = $queries->userInBand($userId)['band_id'];

    $bandDetails = $queries->getMyBand($existingBand);
    $bandDetailsResult = $bandDetails->execute()->fetchAllAssociative();

    $members = $queries->getMembers($existingBand);
    $membersResult = $members->execute()->fetchAllAssociative();

    $userInput = $request->getParsedBody();


    if (isset($_POST['leaveBand'])) {
        $disband = $queries->removeMember($userId);
        $response = $response->withStatus(303);
        return $response->withHeader('Location', 'newsfeed');
    }

    if($queries->isBandAdmin($userId, $existingBand)) {
        if (isset($_POST['disband'])) {
            $disband = $queries->disbandBand($existingBand);
            $deleteBand = $queries->deleteBand($existingBand);
            $response = $response->withStatus(303);
            return $response->withHeader('Location', 'newsfeed');
        }

        if (!empty($userInput['bio'])) {
            $bioContent = $userInput['bio'];
            $cleanedBio = $validator->validateString('bio', $bioContent, 1, 256);
            $storeBio = $queries->storeBandBio($cleanedBio, $userId);
            $response = $response->withStatus(303);
            return $response->withHeader('Location', 'mybandprofile');
        }
    }

    return $this->view->render($response,
        'mybandprofile.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => 'mybandprofilepost',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'My Band',
            'members' => $membersResult,
            'id' => $userId,
            'inband' => $existingBand,
            'banddetails' => $bandDetailsResult,
            'currentUser' => $userId,
        ]);

})->setName('mybandprofile');
