<?php

/**
 * the my profile route is for viewing the current users own profile
 * it gets all their own information from the database and populates the twig template with
 * that data
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->get('/myprofile', function (Request $request, Response $response) use ($app) {

    $queries = $this->get('SqlQueries');

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');
    $existingBand = $queries->userInBand($userId);

    $username = $queries->getMyUsername($userId);
    $usernameResult = $username->execute()->fetchAllAssociative();

    $posts = $queries->getMyPosts($userId);
    $postsResults = $posts->execute()->fetchAllAssociative();

    $bio = $queries->getMyBio($userId);
    $bioResult = $bio->execute()->fetchAllAssociative();

    return $this->view->render($response,
        'myprofile.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => 'myprofilepost',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'My Profile',
            'username' => $usernameResult,
            'MyPosts' => $postsResults,
            'bio' => $bioResult,
            'id' => $userId,
            'inband' => $existingBand,

        ]);

})->setName('myprofile');