<?php

/**
 * the my profile post is for handling any updates made to the profile,
 * if th user updates their bio the data will update and the user
 * be redirected to the get route
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->post('/myprofilepost', function (Request $request, Response $response) use ($app) {

    $queries = $this->get('SqlQueries');
    $validator = $this->get('Validator');

    $error = '';

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');
    $existingBand = $queries->userInBand($userId);

    $username = $queries->getMyUsername($userId);
    $usernameResult = $username->execute()->fetchAllAssociative();

    $posts = $queries->getMyPosts($userId);
    $postsResults = $posts->execute()->fetchAllAssociative();

    $bio = $queries->getMyBio($userId);
    $bioResult = $bio->execute()->fetchAllAssociative();

    $userInput = $request->getParsedBody();

    if (!empty($userInput['bio'])){
        $bioContent = $userInput['bio'];
        $cleanedBio = $validator->validateString('bio', $bioContent, 1, 100);
        $storeBio = $queries->storeBio($cleanedBio, $userId);
        $response = $response->withStatus(303);
        return $response->withHeader('Location', 'myprofile');
    }

    if (isset($_POST['likeStatus']) && isset($_POST['postID'])) {
        if (!$queries->likeExist($_POST['postID'], $userId)) {
            $likePost = $queries->likePost($_POST['postID'], $userId);
            $count = $queries->updateLikes($_POST['postID']);
            $response = $response->withStatus(303);
            return $response->withHeader('Location', 'myprofile');
        } else {
            $error = "You've Already Liked That Post";
        }
    }

    return $this->view->render($response,
        'myprofile.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => 'myprofilepost',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'My Profile',
            'username' => $usernameResult,
            'MyPosts' => $postsResults,
            'bio' => $bioResult,
            'error' => $error,
            'id' => $userId,
            'inband' => $existingBand,
        ]);

})->setName('myprofilepost');