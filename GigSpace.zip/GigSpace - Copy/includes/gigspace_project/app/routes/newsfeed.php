<?php

/**
 * this route displays all of the posts stored within the posts tabel
 * in the db and populates these on the template
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->get('/newsfeed', function (Request $request, Response $response) use ($app) {

    $queries = $this->get('SqlQueries');

    $posts = $queries->getPosts();
    $postResults = $posts->execute()->fetchAllAssociative();

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');
    $existingBand = $queries->userInBand($userId);

    return $this->view->render($response,
        'newsfeed.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => 'newsfeedpost',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'News Feed',
            'postResults' => $postResults,
            'currentUser' => $userId,
            'id' => $userId,
            'inband' => $existingBand,
        ]);

})->setName('newsfeed');