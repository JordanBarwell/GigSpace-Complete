<?php

/**
 * the post method for the newsfeed allows the user to carry out multiple
 * functions. the first being to post a status, when a user submits the action
 * sanitises the user input and then stores it in the db, the user is then redirected to the
 * newsfeed where they can then see that posted status. the can also like any post on the
 * feed, and also make use of the feed filter which filters down the feed
 * to posts which match what the user entered into the filter, it sanitises this input too.
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->post('/newsfeedpost', function (Request $request, Response $response) use ($app) {

    $queries = $this->get('SqlQueries');
    $validator = $this->get('Validator');

    $error = '';

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');

    $existingBand = $queries->userInBand($userId);

    $userInput = $request->getParsedBody();

    $posts = $queries->getPosts();

    $postResults = $posts->execute()->fetchAllAssociative();

    if ($userId) {
        if (isset($_POST['statusBtn'])) {
            if (!empty($userInput['PostBox'])) {
                $postContent = $userInput['PostBox'];
                $cleanedPost = $validator->validateString('PostBox', $postContent, 1, 256);
                $storeStatus = $queries->storeStatusData($cleanedPost, $userId);
                $response = $response->withStatus(303);
                return $response->withHeader('Location', 'newsfeed');
            } else {
                $error = "You gotta type something first!";
            }
        }

        if (isset($_POST['likeStatus']) && isset($_POST['postID'])) {
            if (!$queries->likeExist($_POST['postID'], $userId)) {
                $likePost = $queries->likePost($_POST['postID'], $userId);
                $count = $queries->updateLikes($_POST['postID']);
                $response = $response->withStatus(303);
                return $response->withHeader('Location', 'newsfeed');
            } else {
                $error = "You've Already Liked That Post";
            }
        }
    } else {
        $error = "You're a Guest, sign-up or login to post and like";
    }

    $searchResults = [];
    if (!empty($userInput['search'])) {
        $searchContent = $userInput['search'];
        $cleanedSearch = $validator->validateString('search', $searchContent, 1, 26);
        $search = $queries->feedFilter($cleanedSearch);
        $postResults = $search->execute()->fetchAllAssociative();
        $error = '';
    }

    return $this->view->render($response,
        'newsfeed.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => 'newsfeedpost',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'News Feed',
            'postError' => $error,
            'postResults' => $postResults,
            'currentUser' => $userId,
            'id' => $userId,
            'inband' => $existingBand,
        ]);

})->setName('newsfeedpost');