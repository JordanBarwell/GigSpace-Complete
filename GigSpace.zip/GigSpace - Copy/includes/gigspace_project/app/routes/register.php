<?php

/**
 * if a user is not registered and they wish to make an account
 * the register route displays the register template where they can
 * enter their new account details.
 */

use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->get('/register', function (Request $request, Response $response) use ($app) {


    return $this->view->render($response,
        'registrationform.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => 'registrationfailed',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'Register Here',
            'page_text' => 'Please Enter Your Details Below',
        ]);

})->setName('register');

