<?php

/**
 * this route is for th epost data, if the entered data is wromg or doesnt meet
 * certain requirements then they will remain on this route until they have done so
 * correctly. Once details have been entered correctly the users will be stored in the
 * database, where they can now login to that account.
 */

use GigSpace\SessionManagerInterface;
use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->post('/registrationfailed', function (Request $request, Response $response) use ($app) {

    $validator = $this->get('Validator');
    $taintedParameters = $request->getParsedBody();
    $cleanedParameters = cleanupParameters($app, $taintedParameters);

    $userEmailError = $usernameError = $passwordError = $confirmPasswordError = '';

    if (empty($cleanedParameters['cleanedSitePassword'])) {
        $passwordError = 'This field is required!';
    } elseif (strlen($cleanedParameters['cleanedSitePassword']) > 100) {
        $passwordError = 'password must be less than or equal to 100 characters';
    } elseif (strlen($cleanedParameters['cleanedSitePassword']) < 5) {
        $passwordError = 'password must be 5 Characters or above';
    }

    if (empty($cleanedParameters['cleanedConfirmPassword'])) {
        $confirmPasswordError = 'This field is required!';
    } elseif ($cleanedParameters['cleanedConfirmPassword'] !== $cleanedParameters['cleanedSitePassword']) {
        $confirmPasswordError = 'password does not match';
    }


    if (!$validator->areAllValid()) {
        $validatorError = $validator->getErrors();
        $userEmailError = $validatorError['UserEmail'] ?? '';
        $usernameError = $validatorError['SiteUsername'] ?? '';
    }


    if ($validator->areAllValid() && empty($confirmPasswordError) && empty($passwordError)) {

        $hashedPassword = hashPassword($app, $cleanedParameters['cleanedSitePassword']);

        $data = $this->get('SqlQueries');

        $dataExist = $data->checkUserDetailsExist($cleanedParameters);
        if (!empty($dataExist)) {
            if ($dataExist['username'] === $cleanedParameters['cleanedSiteUsername']) {
                $usernameError = 'Username Already Exists!';
            }
            if ($dataExist['email'] === $cleanedParameters['cleanedUserEmail']) {
                $userEmailError = 'Email Already In Use!';
            }
        }

        if (empty($usernameError) && empty($userEmailError)) {
            $userId = $data->storeUserData($cleanedParameters, $hashedPassword);
            if ($userId) {
                $sessionWrapper = $this->get(SessionWrapperInterface::class);
                $sessionWrapper->set('userId', $userId);
                $this->get(SessionManagerInterface::class)::regenerate($sessionWrapper);
                $response = $response->withStatus(303);
                return $response->withHeader('Location', 'newsfeed');
            }
        }
    }

    return $this->view->render($response,
        'registrationform.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => '',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'Register Here',
            'page_text' => 'Please Enter Your Details Below',
            'password_error' => $passwordError,
            'confirmPassword_error' => $confirmPasswordError,
            'userEmail_error' => $userEmailError,
            'username_error' => $usernameError,
        ]);

})->setName('registrationfailed');

function cleanupParameters($app, $taintedParameters)
{
    $cleanedParameters = [];
    $validator = $app->getContainer()->get('Validator');

    $taintedEmail = $taintedParameters['UserEmail'];
    $taintedUsername = $taintedParameters['SiteUsername'];

    $cleanedParameters['cleanedUserEmail'] = $validator->validateEmail('UserEmail',$taintedEmail);
    $cleanedParameters['cleanedSiteUsername'] = $validator->ValidateString('SiteUsername', $taintedUsername);
    $cleanedParameters['cleanedSitePassword'] = $taintedParameters['SitePassword'];
    $cleanedParameters['cleanedConfirmPassword'] = $taintedParameters['ConfirmPassword'];

    return $cleanedParameters;
}

function hashPassword($app, $passwordForHashing)
{
    $bcryptWrapper = $app->getContainer()->get('BcryptWrapper');
    return $bcryptWrapper->hash($passwordForHashing);
}