<?php

/**
 * this route generates the searchuser template where they can enter details
 * of a bandname or username.
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->get('/searchuser', function (Request $request, Response $response) use ($app) {

    $queries = $this->get('SqlQueries');

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');
    $existingBand = $queries->userInBand($userId);

    return $this->view->render($response,
        'search.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => 'searchuserpost',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'Search Bands & Users',
            'searchResults' => '',
            'currentUser' => $userId,
            'id' => $userId,
            'inband' => $existingBand,
        ]);

})->setName('searchuser');

