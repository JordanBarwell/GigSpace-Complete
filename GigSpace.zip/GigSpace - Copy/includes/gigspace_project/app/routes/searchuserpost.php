<?php

/**
 *  This route is for post action of searching for a user or band
 *  when a user selects what type they would like to search for this route
 *  will then perform the action to that
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->post('/searchuserpost', function (Request $request, Response $response) use ($app) {

    $queries = $this->get('SqlQueries');
    $validator = $this->get('Validator');

    $error = '';

    $userInput = $request->getParsedBody();

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');
    $existingBand = $queries->userInBand($userId)['band_id'];

    $radioInput = ['searchType'];
    $searchResults = [];
    $bandResults = [];

    if (!($radioInput === 'users')) {
        if (!empty($userInput['search'])) {
            $searchContent = $userInput['search'];
            $cleanedSearch = $validator->validateString('search', $searchContent, 1, 26);
            $search = $queries->searchUser($cleanedSearch);
            $searchResults = $search->execute()->fetchAllAssociative();
        }
    }

    if(!($radioInput === 'bands')){
        if (!empty($userInput['search'])) {
            $searchContent = $userInput['search'];
            $cleanedSearch = $validator->validateString('search', $searchContent, 1, 26);
            $search = $queries->searchBand($cleanedSearch);
            $bandResults = $search->execute()->fetchAllAssociative();
        }
    }

    return $this->view->render($response,
        'search.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => 'searchuserpost',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'Search Bands & Users',
            'searchResults' => $searchResults,
            'bandResults' => $bandResults,
            'currentUser' => $userId,
            'id' => $userId,
            'inband' => $existingBand,
        ]);

})->setName('searchuserpost');

