<?php

/**
 * this route grabs all comment data for a specific post, it uses the postID
 * to create a unique route to display all comments associated with the posts
 * comments
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->get('/statuscomment/{post}', function (Request $request, Response $response, $args) use ($app) {

    $queries = $this->get('SqlQueries');

    $postId = $args['post'];

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');
    $existingBand = $queries->userInBand($userId);

    $post = $queries->getSinglePost($postId);

    $postResult = $post->execute()->fetchAllAssociative();

    $comments = $queries->getComments($postId);

    $commentResults = $comments->execute()->fetchAllAssociative();

    return $this->view->render($response,
        'statuscomment.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => "/public_php/gigspace_public/statuscommentpost/$postId",
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'Comments',
            'postError' => '',
            'usersStatus' => $postResult,
            'userComments' => $commentResults,
            'currentUser' => $userId,
            'id' => $userId,
            'inband' => $existingBand,
        ]);

})->setName('statuscomment');
