<?php

/**
 * when a user posts a comment or tries to this the get will direct them to this route
 * where if the user is registered the comment will post, and the user will be redirected
 * to the get method, otherwise if it is a guest trying to post, they will be prompted by an
 * error and remian on the get until the navigate somewhere else.
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->post('/statuscommentpost/{post}', function (Request $request, Response $response, $args) use ($app) {

    $queries = $this->get('SqlQueries');
    $validator = $this->get('Validator');

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');
    $existingBand = $queries->userInBand($userId);

    $postId = $args['post'];

    $post = $queries->getSinglePost($postId);

    $postResult = $post->execute()->fetchAllAssociative();

    $comments = $queries->getComments($postId);

    $commentResults = $comments->execute()->fetchAllAssociative();

    $userInput = $request->getParsedBody();

    if ($userId) {
        if (isset($_POST['statusBtn'])) {
            if (!empty($userInput['PostBox'])) {
                $commentContent = $userInput['PostBox'];
                $cleanedComment = $validator->validateString('PostBox', $commentContent, 1, 256);
                $storeComment = $queries->storeComment($cleanedComment, $userId, $postId);
                $response = $response->withStatus(303);
                return $response->withHeader('Location', "/public_php/gigspace_public/statuscomment/$postId");
            } else {
                $error = "You gotta type something first!";
            }
        }
    } else {
        $error = "You're a Guest, sign-up or login to comment";
    }
    return $this->view->render($response,
        'statuscomment.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => "/public_php/gigspace_public/statuscommentpost/$postId",
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'Comments',
            'postError' => $error,
            'usersStatus' => $postResult,
            'userComments' => $commentResults,
            'currentUser' => $userId,
            'id' => $userId,
            'inband' => $existingBand,
        ]);

})->setName('statuscommentpost');
