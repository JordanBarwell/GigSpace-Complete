<?php

/**
 * the user profile is for other users who arent not the current user.
 * it populates the profile data by the users username which is clicked on by the
 * current user.
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->get('/userprofile/{username}', function (Request $request, Response $response, $args) use ($app) {

    $queries = $this->get('SqlQueries');

    $username = $args['username'];

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');
    $existingBand = $bandDetailsResult = '';

    if($userId) {
        if($queries->userInBand($userId)) {
            $existingBand = $queries->userInBand($userId)['band_id'];
            $bandDetails = $queries->getMyBand($existingBand);
            $bandDetailsResult = $bandDetails->execute()->fetchAllAssociative();
        }
    }

    $existingFriend = $queries->friendsExist($userId, $username)['friend_username'] ?? null;

    $user = $queries->getProfileUsername($username);
    $usernameResult = $user->execute()->fetchAllAssociative();

    $bio = $queries->getUserBio($username);
    $bioResult = $bio->execute()->fetchAllAssociative();

    $posts = $queries->getUserPosts($username);
    $postsResults = $posts->execute()->fetchAllAssociative();

    return $this->view->render($response,
        'userprofile.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => "/public_php/gigspace_public/userprofilepost/$username",
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => "$username's Profile",
            'username' => $usernameResult,
            'bio' => $bioResult,
            'Posts' => $postsResults,
            'currentUser' => $userId,
            'existingFriend' => $existingFriend,
            'id' => $userId,
            'inband' => $existingBand,
            'banddetails' => $bandDetailsResult
        ]);

})->setName('userprofile');
