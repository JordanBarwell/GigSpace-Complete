<?php

/**
 * if the current user is not a guest they can add the user, and if they are existing friends
 * then they can remove them, and if the current user is a band admin another option is available
 * which is to add the user to the band, and if they are then in the current users band
 * they can then remove them.
 */

use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->post('/userprofilepost/{username}', function (Request $request, Response $response, $args) use ($app) {

    $queries = $this->get('SqlQueries');

    $username = $args['username'];

    $sessionWrapper = $this->get(SessionWrapperInterface::class);
    $userId = $sessionWrapper->get('userId');
    $existingBand = $queries->userInBand($userId)['band_id'] ?? null;

    $friendId = $queries->getFriends($userId);

    $user = $queries->getProfileUsername($username);
    $usernameResult = $user->execute()->fetchAllAssociative();

    $existingFriend = $queries->friendsExist($userId, $username)['friend_username'] ?? null;

    $bio = $queries->getUserBio($username);
    $bioResult = $bio->execute()->fetchAllAssociative();

    $posts = $queries->getUserPosts($username);
    $postsResults = $posts->execute()->fetchAllAssociative();


    if (isset($_POST['addFriend'])) {
        if (!$existingFriend) {
            $addFriend = $queries->addFriend($userId, $username);
            $response = $response->withStatus(303);
            return $response->withHeader('Location', "/public_php/gigspace_public/userprofile/$username");
        }
    }

    if (isset($_POST['removeFriend'])) {
        if ($existingFriend) {
            $removeFriend = $queries->removeFriend($userId, $username);
            $response = $response->withStatus(303);
            return $response->withHeader('Location', "/public_php/gigspace_public/userprofile/$username");
        }
    }

    if (isset($_POST['addMember'])) {
        $addMember = $queries->addMember($_POST['userID'], $existingBand);
        $response = $response->withStatus(303);
        return $response->withHeader('Location', "/public_php/gigspace_public/userprofile/$username");
    }

    if (isset($_POST['removeMember'])) {
        $removeMember = $queries->removeMember($_POST['userID']);
        $response = $response->withStatus(303);
        return $response->withHeader('Location', "/public_php/gigspace_public/userprofile/$username");
    }

    if (isset($_POST['likeStatus']) && isset($_POST['postID'])) {
        if (!$queries->likeExist($_POST['postID'], $userId)) {
            $likePost = $queries->likePost($_POST['postID'], $userId);
            $count = $queries->updateLikes($_POST['postID']);
            $response = $response->withStatus(303);
            return $response->withHeader('Location', "/public_php/gigspace_public/userprofile/$username");
        } else {
            $error = "You've Already Liked That Post";
        }
    }

    var_dump($existingFriend);
    var_dump($usernameResult);

    return $this->view->render($response,
        'userprofile.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => "/public_php/gigspace_public/userprofilepost/$username",
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => "$username's Profile",
            'username' => $usernameResult,
            'bio' => $bioResult,
            'Posts' => $postsResults,
            'currentUser' => $userId,
            'existingFriend' => $existingFriend,
            'id' => $userId,
            'inband' => $existingBand,
        ]);

})->setName('userprofilepost');

