<?php

/**
 * the welcome page is what ever user is greeted by, it has three options
 * one to register, one to login so long as the user has an existing account
 * or to enter as a guest.
 */

use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->get('/', function (Request $request, Response $response) use ($app) {


    return $this->view->render($response,
        'welcomepage.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => 'welcomepagepost',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'Welcome to GigSpace',
            'page_text' => 'Please select one of the following options',
        ]);

})->setName('welcomepage');