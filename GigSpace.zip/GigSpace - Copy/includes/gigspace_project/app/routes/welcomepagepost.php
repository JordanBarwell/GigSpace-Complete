<?php

/**
 * the post method of the welcome page is use in the event that the
 * user does not wish to register or login but to enter as a guest
 * the action set to the button is to store a new guest user for the
 * session.
 */

use GigSpace\SessionManagerInterface;
use GigSpace\SessionWrapperInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->post('/welcomepagepost', function (Request $request, Response $response) use ($app) {

    $queries = $this->get('SqlQueries');

    if(isset($_POST['guest'])){
        $guestId = $queries->createGuest();
        $sessionWrapper = $this->get(SessionWrapperInterface::class);
        $sessionWrapper->set('guestId', $guestId);
        $this->get(SessionManagerInterface::class)::regenerate($sessionWrapper);
        $response = $response->withStatus(303);
        return $response->withHeader('Location', 'newsfeed');
    }

    return $this->view->render($response,
        'welcomepage.html.twig',
        [
            'css_path' => CSS_PATH,
            'landing_page' => LANDING_PAGE,
            'page_title' => APP_NAME,
            'action' => 'welcomepagepost',
            'method' => 'post',
            'additional_info' => 'Created By Jordan Barwell',
            'page_heading_1' => 'GIGSPACE',
            'page_heading_2' => 'Welcome to GigSpace',
            'page_text' => 'Please select one of the following options',
        ]);

})->setName('welcomepagepost');
