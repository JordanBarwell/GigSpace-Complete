<?php

namespace GigSpace;

class FileSessionWrapper implements SessionWrapperInterface
{

    /**
     * @var LibSodiumWrapper LibSodiumWrapper used for encrypting/decrypting session values.
     */
    private LibSodiumWrapper $wrapper;

    /**
     * Creates a FileSessionWrapper instance, using a given LibSodiumWrapper for encryption/decryption.
     * @param LibSodiumWrapper $wrapper
     */
    public function __construct(LibSodiumWrapper $wrapper)
    {
        $this->wrapper = $wrapper;
    }

    public function check(string $key): bool
    {
        return isset($_SESSION[$key]);
    }

    public function get(string $key)
    {
        $sessionValue = false;

        if ($this->check($key) !== false) {
            $sessionValue = $this->wrapper->decrypt($_SESSION[$key]);
        }

        return $sessionValue;
    }

    public function set(string $key, $value): bool
    {
        $valueSet = false;

        $encryptedValue = $this->wrapper->encrypt($value);
        if ($encryptedValue !== false) {
            $_SESSION[$key] = $encryptedValue;
            $valueSet = ($_SESSION[$key] === $encryptedValue);
        }

        return $valueSet;
    }

    public function remove(string $key): bool
    {
        unset($_SESSION[$key]);
        return !$this->check($key);
    }

    public function getCsrfToken(string $formTemplateName): string
    {
        $token = $this->get('csrfToken');
        return hash_hmac('sha256', $formTemplateName, $token);
    }

    public function verifyCsrfToken(string $postFormToken, string $formTemplateName): bool
    {
        $token = $this->get('csrfToken');
        $hashedToken = hash_hmac('sha256', $formTemplateName, $token);
        return hash_equals($hashedToken, $postFormToken);
    }

}