<?php

namespace GigSpace;

interface SessionManagerInterface
{

    public static function start(SessionWrapperInterface $wrapper);

    public static function regenerate(SessionWrapperInterface $wrapper);

    public static function destroy(SessionWrapperInterface $wrapper);

}