<?php

namespace GigSpace;

interface SessionWrapperInterface
{

    public function check(string $key): bool;

    public function get(string $key);

    public function set(string $key, $value): bool;

    public function remove(string $key): bool;

    public function getCsrfToken(string $formTemplateName): string;

    public function verifyCsrfToken(string $postFormToken, string $formTemplateName): bool;

}