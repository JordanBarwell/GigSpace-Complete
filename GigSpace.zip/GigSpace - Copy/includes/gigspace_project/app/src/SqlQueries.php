<?php

namespace GigSpace;

use Doctrine\DBAL\Query;
use Doctrine\DBAL\Query\QueryBuilder;
use Psr\Log\LoggerInterface;

class SqlQueries
{

    private LoggerInterface $logger;

    private QueryBuilder $queryBuilder;

    private function resetQueryBuilder(): QueryBuilder
    {

        return $this->queryBuilder->resetQueryParts([
            'select',
            'distinct',
            'from',
            'join',
            'set',
            'where',
            'groupBy',
            'having',
            'orderBy',
            'values'
        ]);
    }

    public function __construct(LoggerInterface $logger, QueryBuilder $queryBuilder)
    {
        $this->logger = $logger;
        $this->queryBuilder = $queryBuilder;
    }

    public function setQueryBuilder(QueryBuilder $queryBuilder)
    {
        $this->queryBuilder = $queryBuilder;
    }

    public function setLogger(LoggerInterface $logger)
    {
        $this->logger = $logger;
    }

    public function storeUserData(array $cleanedParameters, string $hashedPassword)
    {
        $queryBuilder = $this->resetQueryBuilder()->insert('users')
            ->values([
                'username' => ':username',
                'password' => ':password',
                'email' => ':email'
            ])->setParameters([
                'username' => $cleanedParameters['cleanedSiteUsername'],
                'password' => $hashedPassword,
                'email' => $cleanedParameters['cleanedUserEmail']
            ]);

        $storeResult = $queryBuilder->execute();

        if ($storeResult) {
            $userId = $queryBuilder->getConnection()->lastInsertId();
        }

        return $userId;
    }

    public function getUserData(string $username)
    {
        $result = [];
        $queryBuilder = $this->resetQueryBuilder()->select('user_id', 'username', 'password', 'email')
            ->from('users')
            ->where('username = :username')
            ->setParameter('username', $username);

        $result = $queryBuilder->execute()->fetchAssociative();
        return $result;
    }

    public function getUsername()
    {

        $result = null;
        if ($this->queryBuilder !== null) {
            $result = $this->resetQueryBuilder()->select('username')
                ->from('users')
                ->where("username = username");

        }
        return $result;
    }

    public function createGuest()
    {
        $queryBuilder = $this->resetQueryBuilder()->insert('guest_user')
            ->values([
                'guest_username' => ':guest_username',
            ])->setParameters([
                'guest_username' => 'guest',
            ]);

        $storeResult = $queryBuilder->execute();

        if ($storeResult) {
            $guestId = $queryBuilder->getConnection()->lastInsertId();
        }

        return $guestId;
    }

    public function checkUserDetailsExist($parameters)
    {
        $result = [];
        $username = $parameters['cleanedSiteUsername'];
        $email = $parameters['cleanedUserEmail'];

        $queryBuilder = $this->resetQueryBuilder()->select('username', 'email')
            ->from('users')
            ->where('username = :username OR email = :email')
            ->setParameters([
                'username' => $username,
                'email' => $email
            ]);

        $result = $queryBuilder->execute()->fetchAssociative();
        return $result;
    }

    public function storeStatusData(string $cleanedPost, $userID)
    {

        $dateTime = date('Y-m-d H:i:s');

        $queryBuilder = $this->resetQueryBuilder()->insert('posts')
            ->values([
                'user_id' => ':user_id',
                'post_content' => ':post_content',
                'post_date' => ':post_date'
            ])->setParameters([
                'user_id' => $userID,
                'post_content' => $cleanedPost,
                'post_date' => $dateTime
            ]);

        $storeResult = $queryBuilder->execute();

        if ($storeResult) {
            $postId = $queryBuilder->getConnection()->lastInsertId();
        }

        return $postId;

    }

    public function getPosts()
    {

        $result = null;

        if ($this->queryBuilder !== null) {
            $result = $this->resetQueryBuilder()->select('u.username', 'u.user_id', 'p.post_content', 'p.post_date', 'p.likes', 'p.post_id')
                ->from('users', 'u')
                ->from('posts', 'p')
                ->where('p.user_id = u.user_id')
                ->orderBy('post_date', 'DESC');
        }
        return $result;
    }

    public function getMyBandPosts($bandId)
    {

        $result = null;

        if ($this->queryBuilder !== null) {
            $result = $this->resetQueryBuilder()->select('b.band_name', 'u.username', 'u.user_id', 'p.post_content', 'p.post_date', 'p.likes', 'p.post_id')
                ->from('users', 'u')
                ->from('bands', 'b')
                ->from('posts', 'p')
                ->where("b.band_id = u.band_id")
                ->andWhere("b.band_id = $bandId")
                ->andWhere('u.user_id = p.user_id')
                ->orderBy('post_date', 'DESC');
        }
        return $result;
    }

    public function getBandPosts($bandname)
    {

        $result = null;

        if ($this->queryBuilder !== null) {
            $result = $this->resetQueryBuilder()->select('u.user_id', 'u.username', 'b.band_name','b.band_id', 'u.band_id','p.post_content', 'p.post_date', 'p.likes', 'p.post_id')
                ->from('users', 'u')
                ->from('bands', 'b')
                ->from('posts', 'p')
                ->where('b.band_name = :bandname')
                ->andWhere('u.user_id = p.user_id')
                ->andWhere('u.band_id = b.band_id')
                ->orderBy('post_date', 'DESC')
                ->setParameter('bandname', $bandname);
        }
        return $result;
    }

    public function getMyUsername($userId)
    {

        $result = null;
        if ($this->queryBuilder !== null) {
            $result = $this->resetQueryBuilder()->select('username')
                ->from('users')
                ->where("user_id = $userId");

        }
        return $result;
    }

    public function getMyPosts($userId)
    {

        $result = null;

        if ($this->queryBuilder !== null) {
            $result = $this->resetQueryBuilder()->select('u.username', 'p.post_content', 'p.post_date', 'p.likes', 'p.post_id')
                ->from('users', 'u')
                ->from('posts', 'p')
                ->where("p.user_id = $userId")
                ->andWhere('u.user_id = p.user_id')
                ->orderBy('post_date', 'DESC');
        }
        return $result;
    }

    public function storeBio($cleanedBio, $userId)
    {

        $query = $this->resetQueryBuilder()->update('users', 'u')
            ->set('bio', ':bio')
            ->where('u.user_id = :user_id')
            ->setParameter('bio', $cleanedBio)
            ->setParameter('user_id', $userId);

        $storeResult = $query->execute();

    }

    public function getMyBio($userId)
    {

        $result = null;
        if ($this->queryBuilder !== null) {
            $result = $this->resetQueryBuilder()->select('bio')
                ->from('users')
                ->where("user_id = $userId");

        }
        return $result;
    }


    public function getProfileUsername($username)
    {

        $result = null;
        if ($this->queryBuilder !== null) {
            $result = $this->resetQueryBuilder()->select('username', 'user_id', 'band_id')
                ->from('users')
                ->where('username = :username')
                ->setParameter('username', $username);

        }
        return $result;
    }

    public function getUserBio($username)
    {

        $result = null;
        if ($this->queryBuilder !== null) {
            $result = $this->resetQueryBuilder()->select('bio')
                ->from('users')
                ->where('username = :username')
                ->setParameter('username', $username);

        }
        return $result;
    }

    public function getUserPosts($username)
    {

        $result = null;

        if ($this->queryBuilder !== null) {
            $result = $this->resetQueryBuilder()->select('u.username', 'p.post_content', 'p.post_date', 'p.likes', 'p.post_id')
                ->from('users', 'u')
                ->from('posts', 'p')
                ->where('u.username = :username')
                ->andWhere('u.user_id = p.user_id')
                ->orderBy('post_date', 'DESC')
                ->setParameter('u.username', $username);
        }
        return $result;
    }

    public function likeExist($postId, $userId)
    {
        $result = null;

        $query = $this->resetQueryBuilder()->select('like_id')
            ->from('likes')
            ->where('likes.post_id = :postId')
            ->andWhere('likes.user_id = :userId')
            ->setParameters([
                'userId' => $userId,
                'postId' => $postId
            ]);

        $result = $query->execute()->fetchAssociative();
        return $result;
    }

    public function likePost($postId, $userId)
    {

        $query = $this->resetQueryBuilder()->insert('likes')
            ->Values([
                'user_id' => ':user_id',
                'post_id' => ':post_id'
            ])->setParameters([
                'user_id' => $userId,
                'post_id' => $postId
            ]);

        $storeResult = $query->execute();

        if ($storeResult) {
            $likeId = $query->getConnection()->lastInsertId();
        }

        return $likeId;

    }

    public function updateLikes($postId)
    {
        $query = $this->resetQueryBuilder()->update('posts', 'p')
            ->set('likes', 'likes +1')
            ->where("p.post_id = :post_id")
            ->setParameter('post_id', $postId);

        $storeResult = $query->execute();
    }

    public function getSinglePost($postId)
    {

        $result = null;

        if ($this->queryBuilder !== null) {
            $result = $this->resetQueryBuilder()->select('u.username', 'u.user_id', 'p.post_content', 'p.post_date', 'p.likes', 'p.post_id')
                ->from('users', 'u')
                ->from('posts', 'p')
                ->where('p.user_id = u.user_id')
                ->andWhere("post_id = $postId");
        }
        return $result;
    }

    public function storeComment(string $cleanedComment, $userID, $postID)
    {

        $dateTime = date('Y-m-d H:i:s');

        $query = $this->resetQueryBuilder()->insert('post_comment')
            ->values([
                'post_id' => ':post_id',
                'user_id' => ':user_id',
                'comment_content' => ':comment_content',
                'comment_time' => ':comment_time'
            ])->setParameters([
                'post_id' => $postID,
                'user_id' => $userID,
                'comment_content' => $cleanedComment,
                'comment_time' => $dateTime
            ]);

        $storeResult = $query->execute();

        if ($storeResult) {
            $commentId = $query->getConnection()->lastInsertId();
        }

        return $commentId;

    }

    public function getComments($postId)
    {

        $result = null;

        if ($this->queryBuilder !== null) {
            $result = $this->resetQueryBuilder()->select('u.username', 'u.user_id', 'c.comment_content', 'c.comment_time')
                ->from('users', 'u')
                ->from('posts', 'p')
                ->from('post_comment', 'c')
                ->where('c.user_id = u.user_id')
                ->andWhere('c.post_id = p.post_id')
                ->andWhere("p.post_id = $postId")
                ->orderBy('comment_time', 'DESC');
        }
        return $result;

    }

    public function addFriend($userId, $username)
    {
        $query = $this->resetQueryBuilder()->insert('user_friends')
            ->values([
                'user_id' => ':user_id',
                'friend_username' => ':friend_username'
            ])->setParameters([
                'user_id' => $userId,
                'friend_username' => $username
            ]);

        $storeResult = $query->execute();

        if ($storeResult) {
            $friendId = $query->getConnection()->lastInsertId();
        }

        return $friendId;
    }

    public function friendsExist($userId, $username)
    {
        $result = null;

        $query = $this->resetQueryBuilder()->select('friend_username')
            ->from('user_friends')
            ->where('user_friends.user_id = :userId')
            ->andWhere('user_friends.friend_username = :username')
            ->setParameters([
                'userId' => $userId,
                'username' => $username
            ]);

        $result = $query->execute()->fetchAssociative();
        return $result;
    }

    public function removeFriend($userId, $username)
    {

        $query = $this->resetQueryBuilder()->delete('user_friends')
            ->where('user_id = :userId')
            ->andWhere('friend_username = :username')
            ->setParameters([
                'userId' => $userId,
                'username' => $username
            ]);


        $storeResult = $query->execute();
    }

    public function getFriends($userId)
    {
        $result = null;

        if ($this->queryBuilder !== null) {
            $result = $this->resetQueryBuilder()->select('u.username', 'u.bio', 'u.user_id')
                ->from('users', 'u')
                ->from('user_friends', 'f')
                ->where('f.friend_username = u.username')
                ->andWhere("f.user_id = $userId")
                ->andWhere("u.user_id != $userId");
        }
        return $result;
    }

    public function getFriendsPosts($userId)
    {

        $result = null;

        if ($this->queryBuilder !== null) {
            $result = $this->resetQueryBuilder()->select('u.username', 'u.user_id', 'p.post_content', 'p.post_date', 'p.likes', 'p.post_id')
                ->from('users', 'u')
                ->from('posts', 'p')
                ->from('user_friends', 'f')
                ->Where('u.user_id = p.user_id')
                ->andwhere('f.friend_username = u.username')
                ->andWhere("u.user_id != $userId")
                ->andWhere("f.user_id = $userId")
                ->orderBy('post_date', 'DESC');

        }
        return $result;
    }

    public function searchFriend($input, $userId)
    {

        $query = $this->resetQueryBuilder()->select('friend_username', 'user_id', 'friend_id')
            ->from('user_friends')
            ->where("friend_username LIKE :input")
            ->andWhere("user_id = $userId")
            ->setParameter('input', '%' . $input . '%');

        return $query;

    }

    public function searchUser($input)
    {

        $query = $this->resetQueryBuilder()->select('username', 'bio', 'user_id')
            ->from('users')
            ->where("username LIKE :input")
            ->setParameter('input', '%' . $input . '%');

        return $query;

    }

    public function searchBand($input)
    {

        $query = $this->resetQueryBuilder()->select('band_name', 'band_bio', 'band_id')
            ->from('bands')
            ->where("band_name LIKE :input")
            ->setParameter('input', '%' . $input . '%');

        return $query;

    }

    public function feedFilter($input)
    {

        $query = $this->resetQueryBuilder()->select('u.username', 'u.user_id', 'p.post_content', 'p.post_date', 'p.likes', 'p.post_id')
            ->from('users', 'u')
            ->from('posts', 'p')
            ->where('p.post_content LIKE :input')
            ->andWhere("p.user_id = u.user_id")
            ->setParameter('input', '%' . $input . '%');

        return $query;

    }

    public function createBand($bandName, $userId)
    {

        $query = $this->resetQueryBuilder()->insert('bands')
            ->values([
                'band_admin' => ':band_admin',
                'band_name' => ':band_name'
            ])->setParameters([
                'band_admin' => $userId,
                'band_name' => $bandName
            ]);

        $storeResult = $query->execute();

        if ($storeResult) {
            $bandId = $query->getConnection()->lastInsertId();
        }

        return $bandId;
    }

    public function userInBand($userId)
    {
        $result = null;

        $query = $this->resetQueryBuilder()->select('band_id')
            ->from('users')
            ->where('users.band_id IS NOT NULL')
            ->andWhere('users.user_id = :userId')
            ->setParameters([
                'userId' => $userId,
            ]);

        $result = $query->execute()->fetchAssociative();
        return $result;
    }

    public function isBandAdmin($userId, $bandId)
    {
        $result = null;

        $query = $this->resetQueryBuilder()->select('band_admin')
            ->from('bands', 'b')
            ->from('users', 'u')
            ->where('u.band_id = b.band_id')
            ->andWhere("u.user_id = $userId")
            ->andWhere("b.band_id = $bandId");

        $result = $query->execute()->fetchAssociative();
        return $result;
    }

    public function updateUserBandId($userId, $bandId)
    {

        $query = $this->resetQueryBuilder()->update('users', 'u')
            ->set('u.band_id', ':band_id')
            ->where('u.user_id = :user_id')
            ->setParameter('band_id', $bandId)
            ->setParameter('user_id', $userId);

        $storeResult = $query->execute();
    }

    public function storeBandBio($cleanedBio, $userId)
    {

        $query = $this->resetQueryBuilder()->update('bands', 'b')
            ->set('band_bio', ':band_bio')
            ->where('b.band_admin = :band_admin')
            ->setParameter('band_bio', $cleanedBio)
            ->setParameter('band_admin', $userId);

        $storeResult = $query->execute();

    }

    public function getMyBand($bandId)
    {

        $result = null;
        if ($this->queryBuilder !== null) {
            $result = $this->resetQueryBuilder()->select('b.band_name', 'b.band_bio', 'b.band_admin', 'u.user_id', 'b.band_id')
                ->from('bands', 'b')
                ->from('users', 'u')
                ->where("u.band_id = $bandId")
                ->andWhere('b.band_admin = u.user_id')
                ->andWhere("b.band_id = $bandId");

        }
        return $result;
    }

    public function getMyMembers($bandId)
    {
        $result = null;
        if ($this->queryBuilder !== null) {
            $result = $this->resetQueryBuilder()->select('username', 'user_id')
                ->from('users')
                ->where("band_id = $bandId");

        }
        return $result;
    }

    public function addMember($userId, $bandId)
    {

        $query = $this->resetQueryBuilder()->update('users')
            ->set('band_id', $bandId)
            ->where("user_id = :user_id")
            ->setParameter('user_id', $userId);

        $storeResult = $query->execute();

    }

    public function removeMember($userId)
    {

        $query = $this->resetQueryBuilder()->update('users')
            ->set('band_id', 'NULL')
            ->where("user_id = :user_id")
            ->setParameter('user_id', $userId);

        $storeResult = $query->execute();

    }

    public function disbandBand($bandId)
    {

        $query = $this->resetQueryBuilder()->update('users')
            ->set('band_id', 'NULL')
            ->where('band_id = :bandId')
            ->setParameters([
                'bandId' => $bandId
            ]);

        $storeResult = $query->execute();
    }

    public function deleteBand($bandId)
    {
        $query = $this->resetQueryBuilder()->delete('bands')
            ->where('band_id = :bandId')
            ->setParameters([
                'bandId' => $bandId
            ]);

        $storeResult = $query->execute();
    }

    public function getBandDetails($bandname)
    {

        $result = null;
        if ($this->queryBuilder !== null) {
            $result = $this->resetQueryBuilder()->select('band_name', 'band_bio', 'band_id')
                ->from('bands')
                ->where("band_name = :band_name")
                ->setParameter('band_name', $bandname);

        }
        return $result;

    }

    public function getMembers($bandId)
    {

        $result = null;
        if ($this->queryBuilder !== null) {
            $result = $this->resetQueryBuilder()->select('username')
                ->from('users')
                ->andWhere("band_id = $bandId");

        }
        return $result;
    }


}

/*
public function startChat($userId, $friendId)
{

    $dateTime = date('Y-m-d H:i:s');

    $queryBuilder = $this->queryBuilder->insert('chats')
        ->values([
            'user_id' => ':user_id',
            'friend_id' => ':friend_id',
            'date_created' => ':date_created'
        ])->setParameters([
            'user_id' => $userId,
            'friend_id' => $friendId,
            'date_created' => $dateTime
        ]);

    $storeResult = $queryBuilder->execute();

    if ($storeResult) {
        $chatId = $queryBuilder->getConnection()->lastInsertId();
    }

    return $chatId;
}


public function getChat($userId)
{
    $result = null;

    if ($this->queryBuilder !== null) {
        $result = $this->queryBuilder->select('u.username', 'u.user_id', 'f.friend_username', 'f.friend_id', 'c.chat_id', 'c.date_created')
            ->from('chats', 'c')
            ->from('users', 'u')
            ->from('user_friends', 'f')
            ->where('f.friend_username = u.username')
            ->andWhere("c.user_id = $userId")
            ->andWhere("f.user_id = $userId")
            ->andWhere("u.user_id != $userId")
            ->orderBy('date_created', 'DESC');;
    }
    return $result;
}

public function chatExist($userId, $friendId)
{
    $result = null;

    $queryBuilder = $this->queryBuilder->select('c.chat_id','u.user_id', 'f.friend_id',)
        ->from('chats','c')
        ->from('user_friends', 'f')
        ->where('chats.user_id = :user_id')
        ->andWhere('chats.friend_id = :friend_id')
        ->andWhere('friend_id = chats.friend_id')
        ->andWhere('user_id = chats.user_id')
        ->setParameters([
            'user_id' => $userId,
            'friend_id' => $friendId
        ]);

    $result = $queryBuilder->execute()->fetchAssociative();
    return $result;
}
*/



