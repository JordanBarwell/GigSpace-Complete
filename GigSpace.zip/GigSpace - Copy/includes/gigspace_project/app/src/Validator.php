<?php

namespace GigSpace;


class Validator
{

    /**
     * @var array An associative array of errors, keys are the same as they keys given for all validation functions.
     */
    private array $errors = [];

    /**
     * Returns error for the given key.
     * @param string $key Key given to validation function.
     * @return string|null The error message for the given key or null if there isn't an error.
     */
    public function getError(string $key)
    {
        return $this->errors[$key] ?? null;
    }

    /**
     * Returns all errors from the given Validator instance.
     * @return array
     */
    public function getErrors(): array
    {
        return $this->errors;
    }

    /**
     * Checks if a validated value is valid.
     * @param string $key Key given to validation function to check if errors are present.
     * @return bool Whether the given key was valid after validation was performed.
     */
    public function isValid(string $key): bool
    {
        return !isset($this->errors[$key]);
    }

    /**
     * Checks if all validated inputs are valid.
     * @return bool Whether all validated inputs are valid.
     */
    public function areAllValid(): bool
    {
        return empty($this->errors);
    }

    /**
     * tests to see if username exists in the database and if it matches
     * @param string $key Identifying key of the input value, used to store/retrieve errors.
     * @param string $username Username entered to be checked
     * @param SqlQueries $builder Query to check usernames in db
     * @return bool Whether the input matches or not
     */
    public function doesUsernameMatch(string $key, string $username, SqlQueries $builder)
    {
        $result = false;
        $storedUsername = $builder->getUserData($username);

        if ($storedUsername) {
            $result = true;
        } else {
            $this->errors[$key] = 'username does not exist';
        }

        return $result;

    }

    /**
     * Tests that a string's length is between the min and max lengths supplied (inclusive), after sanitizing it.
     * @param string $key Identifying key of the input value, used to store/retrieve errors.
     * @param string $value String to be checked.
     * @param int $minLength Minimum String Length. (inclusive)
     * @param int $maxLength Maximum String Length. (inclusive)
     * @return false|string Sanitized string or false if invalid.
     */
    public function validateString(string $key, string $value, int $minLength = 5, int $maxLength = 30)
    {
        $result = false;

        if (strlen($value) <= $maxLength) {
            $sanitizedString = filter_var($value, FILTER_SANITIZE_STRING, FILTER_FLAG_NO_ENCODE_QUOTES);
            $sanitizedStringLength = strlen($sanitizedString);

            if (empty($value) && $minLength !== 0) {
                $this->errors[$key] = 'This field is required!';
            } elseif ($sanitizedStringLength < $minLength || $sanitizedStringLength > $maxLength) {
                $this->errors[$key] = "Must be between $minLength and $maxLength characters!";
            } else {
                $result = $sanitizedString;
            }
        } else {
            $this->errors[$key] = "Must not be longer than $maxLength characters!";
        }

        return $result;
    }

    /**
     * Tests if the entered string is a valid email address.
     * @param string $key Identifying key of the input value, used to store/retrieve errors.
     * @param string $value Email string to be checked.
     * @return bool|string Email address or false if it's invalid.
     */
    public function validateEmail(string $key, string $value)
    {
        $result = false;

        if (!empty($value) && strlen($value) <= 300) {
            $sanitisedEmail = filter_var($value, FILTER_SANITIZE_EMAIL);
            $validatedEmail = filter_var($sanitisedEmail, FILTER_VALIDATE_EMAIL);

            if ($validatedEmail === false) {
                $this->errors[$key] = 'Must be a valid e-mail address!';
            } else {
                $result = $validatedEmail;
            }
        } elseif (strlen($value) > 300) {
            $this->errors[$key] = 'Must be a valid e-mail address!';
        } else {
            $this->errors[$key] = 'This field is required!';
        }

        return $result;
    }

}