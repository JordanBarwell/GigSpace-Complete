<?php

use GigSpace\Validator;
use PHPUnit\Framework\TestCase;


class ValidatorTest extends TestCase
{

    public function testValidateStringCorrect()
    {
        $validator = new GigSpace\Validator();
        $value = 'ABCDEF';
        $this->assertNotFalse($validator->validateString('test', $value));
    }

    public function testValidateStringEmpty()
    {
        $validator = new GigSpace\Validator();
        $value = '';
        $this->assertFalse($validator->validateString('test', $value));
        $this->assertEquals('This field is required!', $validator->getError('test'));
    }

    public function testValidateStringLessThanMinLength()
    {
        $validator = new GigSpace\Validator();
        $value = 'ABCD';
        $this->assertFalse($validator->validateString('test', $value, 5, 10));
        $this->assertEquals('Must be between 5 and 10 characters!', $validator->getError('test'));
    }


    public function testValidateStringGreaterThanMaxLength()
    {
        $validator = new GigSpace\Validator();
        $value = 'ABCD';
        $this->assertFalse($validator->validateString('test', $value, 1, 3 ));
        $this->assertEquals('Must not be longer than 3 characters!', $validator->getError('test'));
    }


    public function testValidateEmailCorrect()
    {
        $validator = new GigSpace\Validator();
        $value = 'jordan@mail.com';
        $this->assertNotFalse($validator->validateEmail('test', $value));
    }

    public function testValidateEmailString()
    {
        $validator = new GigSpace\Validator();
        $value = 'jordan';
        $this->assertFalse($validator->validateEmail('test', $value));
        $this->assertEquals('Must be a valid e-mail address!', $validator->getError('test'));
    }

    public function testValidateEmailEmpty()
    {
        $validator = new GigSpace\Validator();
        $value = '';
        $this->assertFalse($validator->validateEmail('test', $value));
        $this->assertEquals('This field is required!', $validator->getError('test'));
    }

    public function testValidateEmailTooLong()
    {
        $validator = new GigSpace\Validator();
        $value = str_repeat('a', 301);
        $this->assertFalse($validator->validateEmail('test', $value));
        $this->assertEquals('Must be a valid e-mail address!', $validator->getError('test'));
    }
}