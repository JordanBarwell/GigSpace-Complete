<?php

use \Slim\{Container, App};
use \GigSpace\{SessionManagerInterface, SessionWrapperInterface};

require '../../includes/vendor/autoload.php';

$settings = require __DIR__ . '/app/settings.php';

$makeTrace = false;

if ($makeTrace && function_exists('xdebug_start_trace'))
{
    xdebug_start_trace();
}

$container = new Container($settings);

require __DIR__ . '/app/dependencies.php';

$app = new App($container);

require __DIR__ . '/app/middleware.php';
require __DIR__ . '/app/routes.php';

$app->run();

if ($makeTrace && function_exists('xdebug_stop_trace')) {
    xdebug_stop_trace();
}