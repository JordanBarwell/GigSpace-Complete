DROP
DATABASE IF EXISTS gigspace_db;

CREATE
DATABASE gigspace_db COLLATE utf8_unicode_ci;

CREATE
USER IF NOT EXISTS 'gigspace_user'@'localhost' IDENTIFIED BY 'gigspace_pass';
GRANT
SELECT,
INSERT
ON gigspace_db.* TO 'gigspace_user'@localhost;

USE
gigspace_db;


DROP TABLE IF EXISTS `bands`;
CREATE TABLE `bands`
(
    `band_id`    BIGINT       NOT NULL AUTO_INCREMENT,
    `band_admin` BIGINT       NOT NULL,
    `band_name`  VARCHAR(26)  NOT NULL,
    `band_bio`   VARCHAR(256) NULL,
    PRIMARY KEY (`band_id`),
    FOREIGN KEY (`band_admin`) REFERENCES users (`user_id`)
) ENGINE=InnoDB;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`
(
    `user_id`      BIGINT       NOT NULL AUTO_INCREMENT,
    `user_picture` BLOB NULL,
    `username`     VARCHAR(26)  NOT NULL,
    `password`     VARCHAR(256) NOT NULL,
    `email`        VARCHAR(300) NOT NULL,
    `bio`          VARCHAR(256) NULL,
    `band_id`      BIGINT       NULL,
    PRIMARY KEY (`user_id`),
    FOREIGN KEY (`band_id`) REFERENCES bands (`band_id`),
    CONSTRAINT UC_User UNIQUE (`username`, `email`)
) ENGINE=InnoDB;

DROP TABLE IF EXISTS `guest_user`;
CREATE TABLE `guest_user`
(
    `guest_id`       BIGINT      NOT NULL AUTO_INCREMENT,
    `guest_username` VARCHAR(26) NOT NULL,
    PRIMARY KEY (`guest_id`)
) ENGINE=InnoDB;

DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts`
(
    `post_id`      BIGINT       NOT NULL AUTO_INCREMENT,
    `user_id`      BIGINT       NOT NULL,
    `post_content` VARCHAR(256) NOT NULL,
    `post_date`    DATETIME     NOT NULL,
    `likes`        BIGINT DEFAULT '0',
    PRIMARY KEY (`post_id`),
    FOREIGN KEY (`user_id`) REFERENCES users (`user_id`)
) ENGINE=InnoDB;

DROP TABLE IF EXISTS `likes`;
CREATE TABLE `likes`
(
    `like_id` BIGINT NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT NOT NULL,
    `post_id` BIGINT NOT NULL,
    PRIMARY KEY (`like_id`),
    FOREIGN KEY (`user_id`) REFERENCES users (`user_id`),
    FOREIGN KEY (`post_id`) REFERENCES posts (`post_id`)
) ENGINE=InooDB;

DROP TABLE IF EXISTS `post_comment`;
CREATE TABLE `post_comment`
(
    `comment_id`      BIGINT       NOT NULL AUTO_INCREMENT,
    `user_id`         BIGINT       NOT NULL,
    `post_id`         BIGINT       NOT NULL,
    `comment_content` VARCHAR(256) NOT NULL,
    `comment_time`    DATETIME     NOT NULL,
    PRIMARY KEY (`comment_id`),
    FOREIGN KEY (`user_id`) REFERENCES users (`user_id`),
    FOREIGN KEY (`post_id`) REFERENCES posts (`post_id`)
) ENGINE=InnoDB;

DROP TABLE IF EXISTS `user_friends`;
CREATE TABLE `user_friends`
(
    `friend_id`       BIGINT      NOT NULL AUTO_INCREMENT,
    `user_id`         BIGINT      NOT NULL,
    `friend_username` VARCHAR(26) NOT NULL,
    PRIMARY KEY (`friend_id`),
    FOREIGN KEY (`user_id`) REFERENCES users (`user_id`)
) ENGINE=InnoDB;

DROP TABLE IF EXISTS `chats`;
CREATE TABLE `chats`
(
    `chat_id`      BIGINT   NOT NULL AUTO_INCREMENT,
    `user_id`      BIGINT   NOT NULL,
    `friend_id`    BIGINT   NOT NULL,
    `date_created` DATETIME NOT NULL,
    PRIMARY KEY (`chat_id`),
    FOREIGN KEY (`user_id`) REFERENCES users (`user_id`),
    FOREIGN KEY (`friend_id`) REFERENCES user_friends (`friend_id`)
) ENGINE=InnoDB;

DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages`
(
    `message_id` BIGINT       NOT NULL AUTO_INCREMENT,
    `chat_id`    BIGINT       NOT NULL,
    `user_id`    BIGINT       NOT NULL,
    `friend_id`  BIGINT       NOT NULL,
    `message`    VARCHAR(500) NOT NULL,
    `time_sent`  DATETIME     NOT NULL,
    PRIMARY KEY (`message_id`),
    FOREIGN KEY (`chat_id`) REFERENCES chats (`chat_id`),
    FOREIGN KEY (`friend_id`) REFERENCES user_friends (`friend_id`)
) ENGINE=InnoDB;

